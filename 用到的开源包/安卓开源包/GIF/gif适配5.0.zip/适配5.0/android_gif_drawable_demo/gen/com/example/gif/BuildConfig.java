/** Automatically generated file. DO NOT MODIFY */
package com.example.gif;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}