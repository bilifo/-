package com.example.gif;

import java.io.IOException;
import java.security.PublicKey;

import org.apache.http.Header;

import pl.droidsonroids.gif.AnimationListener;
import pl.droidsonroids.gif.GifDrawable;
import pl.droidsonroids.gif.GifImageView;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.res.Resources.NotFoundException;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;
import android.widget.Toast;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;

public class MainActivity extends Activity {

	private GifImageView network_gifimageview;
	private AsyncHttpClient asyncHttpClient;
	String string = "http://cdn.duitang.com/uploads/item/201311/20/20131120213622_mJCUy.thumb.600_0.gif";

	// private ProgressDialog dialog;

	public void gifPlayEnd() {

	}

	GifDrawable gbDrawable;
	GifImageView gvView;

	public void onClick() {

	}

	public interface ClickListener {
		public void onClick();
	}

	private class Button {
		private MainActivity activity;
		private ClickListener mClickListener;

		public void setClickActivity(MainActivity activity) {
			this.activity = activity;
		}

		public void setClickListener(ClickListener l) {
			mClickListener = l;
		}

		public void ru() {
			// /....
			// activity.onClick();
			mClickListener.onClick();
		}
	}

	private class MyClickListener implements ClickListener {

		@Override
		public void onClick() {

		}

	}

	@SuppressLint("NewApi")
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		Button button = new Button();
		// button.setClickActivity(this);
		ClickListener listener = new ClickListener() {

			@Override
			public void onClick() {
				// TODO Auto-generated method stub

			}
		};

		MyClickListener clickListener = new MyClickListener();
		button.setClickListener(clickListener);

		gvView = (GifImageView) findViewById(R.id.gif_image);
		try {
			gbDrawable = new GifDrawable(getResources(), R.drawable.load);
			gbDrawable.setLoopCount(4);//设置循环次数
			gvView.setImageDrawable(gbDrawable);
		} catch (NotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		gbDrawable.addAnimationListener(new AnimationListener() {

			@Override
			public void onAnimationCompleted() {
				Log.i("test", "activity animationcompleted...",
						new RuntimeException());
				/*
				 * try { gbDrawable=new GifDrawable(getResources(),
				 * R.drawable.load); } catch (NotFoundException e) { // TODO
				 * Auto-generated catch block e.printStackTrace(); } catch
				 * (IOException e) { // TODO Auto-generated catch block
				 * e.printStackTrace(); } gvView.setImageDrawable(gbDrawable);
				 */
				// gbDrawable.reset();
				// gbDrawable.start();
			}
		});

		if (gbDrawable.isAnimationCompleted()) {
			Log.i("test", "activity animationcompleted.22..");
			gvView.setImageDrawable(gbDrawable);
		}

		network_gifimageview = (GifImageView) findViewById(R.id.network_gifimageview);
		final String st = SharedPreferencesUtils.getParam(this, "zidong", "");
		System.out.println(st + "+1");
		// SharedPreferencesUtils.setParam(this, "zidong", "");
		setImage();
		network_gifimageview.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				if (st.equals("")) {
					System.out
							.println("11111111111111111111111111111111111111");
				}

				// setImage();
			}
		});

	}

	public void setImage() {
		asyncHttpClient = new AsyncHttpClient();
		asyncHttpClient.get(string, new AsyncHttpResponseHandler() {

			@Override
			public void onSuccess(int arg0, Header[] arg1, byte[] arg2) {
				// TODO Auto-generated method stub

				GifDrawable drawable = null;
				try {
					drawable = new GifDrawable(arg2);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				drawable.start();
				network_gifimageview.setBackgroundDrawable(drawable);

			}

			@Override
			public void onFailure(int arg0, Header[] arg1, byte[] arg2,
					Throwable arg3) {
				// TODO Auto-generated method stub
				Toast.makeText(getApplicationContext(), "��������ͼƬ����",
						Toast.LENGTH_SHORT).show();
				// dialog.dismiss();

			}
		});
	}
}
